import setuptools

setuptools.setup(
    name='mypackage',
    version='0.1.1',
    author='MrCrash',
    description='My first package',
    include_package_data=True,
    packages=setuptools.find_packages(),
)