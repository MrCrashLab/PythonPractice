def return_script(anyway):
    return anyway


def summ(a, b):
    return a + b


def diff(a, b):
    return a - b


def mul(a, b):
    return a * b


if __name__ == "__main__":
    print("Is main scrypt")